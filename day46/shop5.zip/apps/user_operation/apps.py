from django.apps import AppConfig


class UserOperationConfig(AppConfig):
    name = 'user_operation'
