from django.db import models

# Create your models here.
class BookInfo(models.Model):
    btitle=models.CharField(max_length=20,db_index=True)
    bpub_date=models.DateField()
    # 增加新列时，如果数据库中原本表已经数据，要增加default
    # 价格,最大位数为10,小数为2,default 是django的模型类层使用的
    bprice = models.DecimalField(max_digits=10, decimal_places=2,default=0,null=True,blank=True)
    # 阅读量
    bread = models.IntegerField(default=0)
    # 评论量
    bcomment = models.IntegerField(default=0)
    # 删除标记
    isDelete = models.BooleanField(default=False)

    # 重新str后，打印对象会得到return返回值的内容
    def __str__(self):
        return self.btitle

class HeroInfo(models.Model):
    hname = models.CharField(max_length=20)
    hgender = models.BooleanField(default=False)
    hcomment = models.CharField(max_length=100)
    # on_delete=models.CASCADE  删除Bookinfo里边的书籍时，
    # 会自动删除依赖该书籍的英雄信息
    hbook=models.ForeignKey('BookInfo',on_delete=models.CASCADE,db_constraint=False)
    # 删除标记
    isDelete = models.BooleanField(default=False)
    # 重新str后，打印对象会得到return返回值的内容
    def __str__(self):
        return self.hname