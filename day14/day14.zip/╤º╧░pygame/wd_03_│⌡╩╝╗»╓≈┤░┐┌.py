# 作者: 王道 龙哥
# 2022年03月01日15时01分03秒

import pygame
import time
pygame.init()

# 创建游戏的窗口 480 * 700
screen = pygame.display.set_mode((480, 700))

while True:
    time.sleep(1)

pygame.quit()