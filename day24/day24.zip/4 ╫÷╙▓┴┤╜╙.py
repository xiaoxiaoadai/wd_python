# 作者: 王道 龙哥
# 2022年03月12日11时52分04秒
import os
# 秒传
os.link('abc.mp4','m.mp4')