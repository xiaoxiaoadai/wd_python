# 作者: 王道 龙哥
# 2022年03月28日11时13分47秒
from django.urls import path
from snippets import views

urlpatterns = [
    path('snippets/', views.snippet_list),
    path('snippets/<int:pk>/', views.snippet_detail),
]