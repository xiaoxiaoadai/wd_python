# 作者: 王道 龙哥
# 2022年04月06日10时19分47秒
from rest_framework import permissions


class IsOwnerOrReadOnly(permissions.BasePermission):
    """
    删除时，不同用户不能删除其他用户的收藏
    """

    def has_object_permission(self, request, view, obj):
        # Read permissions are allowed to any request,
        # so we'll always allow GET, HEAD or OPTIONS requests.
        if request.method in permissions.SAFE_METHODS:
            return True

        # Instance must have an attribute named `owner`.
        return obj.user == request.user