from django.test import TestCase

# Create your tests here.
import datetime

print(datetime.date(2009,1,1))
print(datetime.datetime(2009,1,1,8,9,10))