# 作者: 王道 龙哥
# 2022年03月04日15时10分46秒


list1=[1,2,3,4,5]

for i in list1:
    if i==3:
        j=i

print(j)
print(list1)