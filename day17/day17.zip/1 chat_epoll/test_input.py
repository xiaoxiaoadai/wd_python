# 作者: 王道 龙哥
# 2022年03月04日10时59分09秒

import time

# time.sleep(5)
data=input('请输入什么')
print(data)