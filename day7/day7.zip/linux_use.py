#!/usr/bin/python
print('helloworld')
print('helloworld')
print('helloworld')