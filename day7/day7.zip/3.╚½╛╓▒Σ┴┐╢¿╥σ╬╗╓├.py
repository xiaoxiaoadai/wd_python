a = 10


def demo():
    print("%d" % a)
    print("%d" % b)
    print("%d" % c)


b = 20
demo()
c = 30  #这里会报错
