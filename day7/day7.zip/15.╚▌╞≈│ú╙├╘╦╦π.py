#!/usr/bin/python
# author luke
# 2022年02月21日


a = [1, 2]
b = [3, 4]
c = a + b
print(c)
print(a)



#  初始化10个零
a=[0]*10
print(a)
a[5]=10

# in运算
print('d' in 'abc')
a = {'name': 'zhangsan','age': 15}
print('name' in a) #字典的in是找的键



# 列表和元素比大小
print((1,2,3)<(1,1,-1))