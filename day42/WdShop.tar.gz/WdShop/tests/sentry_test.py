import sentry_sdk
sentry_sdk.init("https://aa459ac0bc2b4f07a574bbee2556dff8@sentry.io/1825955")
division_by_zero = 1 / 0