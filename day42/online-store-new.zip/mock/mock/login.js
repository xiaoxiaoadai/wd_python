module.exports = {
    msg:'登录成功',
    info:{
        name:'admin',
        id:1
    }
}



