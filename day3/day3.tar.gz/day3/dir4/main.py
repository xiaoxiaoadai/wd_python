#!/usr/bin/python3
# coding=utf-8
#Author:luke aa
#email:daxuelu@foxmail.com

print('hello')
print('hello1')
print('hello2')
print('hello3')
print('hello4')

