#!/usr/bin/python
# author luke
# 2022年02月22日

for i in range(10):
    if i == 15:
        print('i have 15')
        break
else:
    print("don't find")
