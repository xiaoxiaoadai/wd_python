#!/usr/bin/python
# author luke
# 2022年02月22日

# 引用计数

str1='hello'
str2='hello'
print(id(str1))
print(id(str2))


