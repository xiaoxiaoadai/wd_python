# 作者: 王道 龙哥
# 2022年03月21日16时12分57秒

#一个是可变类型，一个是不可变类型
RECV_DATA_LIST=[]
HANDLE_FLAG=False