# 作者: 王道 龙哥
# 2022年03月21日15时25分47秒
from test import *
from 验证私有属性的导入 import *
# print(_name1)
# _Bug.showbug()