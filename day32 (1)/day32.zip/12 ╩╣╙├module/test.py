# 作者: 王道 龙哥
# 2022年03月22日11时22分05秒
class Person(object):
    def __init__(self):
        self.name = 'laowang'