# 作者: 王道 龙哥
# 2022年03月22日11时44分23秒
def m3():
    with open("output.txt", "r") as f:
        f.write("Python之禅")





if __name__ == '__main__':
    m3()