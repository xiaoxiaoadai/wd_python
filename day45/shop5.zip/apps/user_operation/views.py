from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from rest_framework import mixins
from rest_framework.permissions import IsAuthenticated

from .models import UserFav
from .permissions import IsOwnerOrReadOnly
from .serializers import UserFavSerializer
# Create your views here.


class UserFavViewset(mixins.ListModelMixin,mixins.CreateModelMixin,mixins.RetrieveModelMixin,
                     mixins.DestroyModelMixin,viewsets.GenericViewSet):
    '''
    用户收藏功能 CreateModelMixin是搞添加收藏，DestroyModelMixin是搞删除收藏
    '''
    # queryset = UserFav.objects.all()  #查询数据集合，任何类都要拿数据才能操作
    serializer_class = UserFavSerializer #序列化类
    permission_classes = (IsAuthenticated,IsOwnerOrReadOnly)
    lookup_field = "goods_id"
    def get_queryset(self):
        """
        让每个人只看到自己的收藏
        :return:
        """
        return UserFav.objects.filter(user=self.request.user)