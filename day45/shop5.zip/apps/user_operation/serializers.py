# 作者: 王道 龙哥
# 2022年04月06日10时04分29秒
from rest_framework import serializers
from rest_framework.validators import UniqueTogetherValidator

from .models import UserFav
from .models import UserLeavingMessage, UserAddress
from goods.serializers import GoodsSerializer

class UserFavSerializer(serializers.ModelSerializer):
    user = serializers.HiddenField(
        default=serializers.CurrentUserDefault(),error_messages={
                                     "required": "匿名用户无法收藏"}
    )  #不需要前端提交用户id，因为JWT token中带了

    class Meta:
        model = UserFav
        validators = [
            UniqueTogetherValidator(
                queryset=UserFav.objects.all(),
                fields=('user', 'goods'),
                message="已经收藏"
            )
        ] #用户不能重复收藏某个商品

        fields = ("user", "goods", "id")