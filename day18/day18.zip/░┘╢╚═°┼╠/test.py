# 作者: 王道 龙哥
# 2022年03月05日11时10分42秒
import os


# path=os.getcwd()
# print(path)
# data = ''
# for file in os.listdir(path):
#     data += file + ' ' * 5 + str(os.stat(file).st_size) + '\n'
# print(data)

# print(os.getcwd())
# path='cd  dir1'.split()[1]
# os.chdir('H:\\')
# print(os.getcwd())

os.remove('file')