# 作者: 王道 龙哥
# 2022年03月08日09时49分22秒
import time
from threading import Thread


def saySorry():
    print("亲爱的，我错了，我能吃饭了吗？")
    time.sleep(1)


if __name__ == "__main__":
    for i in range(5):
        t = Thread(target=saySorry)
        t.start()
