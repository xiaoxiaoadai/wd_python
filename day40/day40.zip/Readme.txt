为snippets/<int:pk>/highlight/增加超链接

视图集中使用set_password