# 作者: 王道 龙哥
# 2022年03月24日10时59分21秒
# x = 300

def test1():
    x = 200

    def test2():
        nonlocal x  #如果要使用外部函数的变量，需要加nonlocal
        print("----1----x=%d" % x)
        x = 100
        print("----2----x=%d" % x)

    return test2


t1 = test1()
t1()
