-----copyright版权......
运行方式：./run.sh
或者 python3 xxx.py 7890 mini_frame:application

author:laowang
date:xxx
versioin:1.0
