# 作者: 王道 龙哥
# 2022年03月03日11时29分13秒

import sys

for i in sys.argv:
    print(i)