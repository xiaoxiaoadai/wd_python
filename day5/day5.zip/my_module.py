name = '王道训练营'


def print_line(char):
    print(char * 50)
