from django.shortcuts import render

# Create your views here.
from rest_framework.viewsets import ModelViewSet
from books.models import BookInfo
from .serializers import BookInfoSerializer


# Create your views here.
class BookInfoAPIView(ModelViewSet):
    # 当前视图类所有方法使用得数据结果集是谁?
    queryset = BookInfo.objects.all()
    # 当前视图类使用序列化器类是谁
    serializer_class = BookInfoSerializer
