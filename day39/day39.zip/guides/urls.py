# 作者: 王道 龙哥
# 2022年03月30日11时14分02秒
from django.contrib import admin
from django.urls import path, include, re_path

#re_path里边第一个参数是正则表达式
from guides.views import FileUploadView,simple_html_view

urlpatterns = [
    path('upload/<str:filename>/', FileUploadView.as_view()),
    path('simple_html_view/',simple_html_view),
]