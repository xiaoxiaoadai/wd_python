#布尔类型可以做数值运算
i=3+True
print(i)