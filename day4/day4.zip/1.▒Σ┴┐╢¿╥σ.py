qq_number='123456'
qq_passwd='123'
print(qq_number)
print(qq_passwd)


# 定义苹果价格变量
price = 8

# 定义购买重量
weight = 7.5

# 计算金额
money = price * weight

print(money)

sex=False
print(type(qq_passwd))
print(type(price))
print(type(weight))
print(type(sex))