# 这是我的第二个python程序
print('hello2 py')
i=5