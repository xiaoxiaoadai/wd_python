num=123
# 0和1
print(bin(num))
# 0-7  二进制变八进制，每3位为1体
print(oct(num))
#0-9  a-f   二进制变十六进制，每4位为1体
print(hex(num))

