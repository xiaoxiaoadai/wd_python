
print('hello python')
print(3+4)
i=10
i=5
i=2