# 转义字符学习
print('\\\\')
print('hello\'world')

print("hello'world")
print('how',end='')
print('are')
print('abc\rd')  #\r回到行首
print('hello')

first_name='张'
last_name='三'
print(first_name+last_name)
print('-'*50)
# print(10+first_name)   不支持整型加字符串