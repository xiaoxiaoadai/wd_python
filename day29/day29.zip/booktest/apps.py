from django.apps import AppConfig


class BooktestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'booktest'
