
import io
f = io.BytesIO()

print(type(f))