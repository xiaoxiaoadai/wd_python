from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from booktest.models import BookInfo,HeroInfo,Areas
from datetime import date
from django.db.models import F,Q
from django.db.models import Sum,Count,Max,Min,Avg
# Create your views here.

def index(request):
    # return HttpResponse('hello python')
    # return my_render(request,'booktest/index.html',{'content':'hello world'})
    return render(request,'booktest/index.html',{'content':'hello world'})
def index2(request):
    # 练习F对象和Q对象
    print(BookInfo.objects.filter(bread__gt=F('bcomment')*2))
    print(BookInfo.objects.filter(id__gt=2, bread__gt=19))
    print(BookInfo.objects.filter(Q(id__gt=2)&Q(bread__gt=19)))
    # 例：查询id大于3或者阅读量大于30的图书的信息。
    print(BookInfo.objects.filter(Q(id__gt=3)|Q(bread__gt=30)))
    # 例：查询id不等于3图书的信息。
    print(BookInfo.objects.filter(~Q(id=3)))
    return HttpResponse('hello python2')

# 加载模板文件，对模板进行一些处理，返回给前端
def my_render(request,template_path,context_dict={}):
    # 1.加载模板文件, 模板对象
    temp = loader.get_template(template_path)
    # 2.定义模板上下文:给模板文件传递数据，模板渲染:产生标准的html内容
    res_html = temp.render(context_dict)
    # 3.返回给浏览器
    return HttpResponse(res_html)

def show_books(request):
    books=BookInfo.objects.all()
    return render(request,'booktest/show_books.html',{'books':books})

def detail(request,bid):
    # 1.根据bid查询图书信息
    book=BookInfo.objects.get(id=bid)
    # 2.根据book查询关联的英雄信息
    heros = book.heroinfo_set.all()
    # 3.使用模板
    return render(request,'booktest/detail.html',{'book':book,'heros':heros})


def create(request):
    '''新增一本图书'''
    # 1.创建BookInfo对象
    b = BookInfo()
    b.btitle = '跟龙哥学C语言'
    b.bpub_date = date(2019,10,1)
    # 2.保存进数据库
    b.save()
    # 3.返回应答,让浏览器再访问/books,重定向
    # return HttpResponse('ok')
    return HttpResponseRedirect('/books')

def delete(request, bid):
    '''删除点击的图书'''
    # 1.通过bid获取图书对象
    book = BookInfo.objects.get(id=bid)
    # 2.删除
    book.delete()
    # 3.重定向，让浏览器访问/index
    return HttpResponseRedirect('/books')

# 使用聚合
def use_aggregate(request):
    print(BookInfo.objects.all().aggregate(Count('id')))
    print(BookInfo.objects.aggregate(Sum('bread')))
    # 例：统计所有图书的数目。
    print(BookInfo.objects.all().count())
    print(BookInfo.objects.count())
    # 例：统计id大于3的所有图书的数目。
    print(BookInfo.objects.filter(id__gt=3).count())
    return HttpResponse('ok')

# 关联查询
def realation_search(request):
    # 例：查询图书信息，要求图书关联的英雄的描述包含'八'。
    print(BookInfo.objects.filter(heroinfo__hcomment__contains='八'))
    # 例：查询图书信息，要求图书中的英雄的id大于3.
    print(BookInfo.objects.filter(heroinfo__id__gt=3))
    # 例：查询书名为“天龙八部”的所有英雄。
    print(HeroInfo.objects.filter(hbook__btitle='天龙八部'))
    return HttpResponse('ok')

def areas(request):
    '''获取广州市的上级地区和下级地区'''
    # 1.获取广州市的信息
    area = Areas.objects.get(atitle='深圳市')
    # 2.查询广州市的上级地区
    parent = area.aParent
    # 3.查询广州市的下级地址
    children = area.areas_set.all()
    # 使用模板
    return render(request, 'booktest/area.html', {'area':area,'parent':parent, 'children':children})