# author luke
# 2022年02月26日11时06分13秒


# 1 == 0 and print('hello')
# 1 == 0 or print('hello')

# for i in range(10//2-1,-1,-1):
#     print(i)

# list1="3 87 2 93 78 56 61 38 12 40".split()
# for i in range(10):
#     list1[i]=int(list1[i])
#
# print(list1)

a=[3, 87, 2, 93, 78, 56, 61, 38, 12, 40]
b=[13, 15, 49, 58, 63, 67, 83, 88, 94, 97]
a[2:6]=b[2:6]
print(a)
