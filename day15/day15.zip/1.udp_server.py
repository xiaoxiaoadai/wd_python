# 作者: 王道 龙哥
# 2022年03月02日10时30分50秒
import socket

#代码即注释
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
addr=('192.168.5.7',2000)  #写1024以上端口
s.bind(addr)  #失败直接抛异常
data,client_addr=s.recvfrom(5) #100代表接的长度
print(data.decode('utf8'))
print(client_addr)
data,client_addr=s.recvfrom(5) #100代表接的长度
print(data.decode('utf8'))
print(client_addr)
s.sendto('很牛'.encode('utf8'),client_addr)
s.close()
