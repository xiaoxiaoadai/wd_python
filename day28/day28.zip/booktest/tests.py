from django.test import TestCase
from booktest.models import BookInfo

# Create your tests here.
#聚合操作在这里
class AnimalTestCase(TestCase):
    # def setUp(self):
    #     Animal.objects.create(name="lion", sound="roar")
    #     Animal.objects.create(name="cat", sound="meow")

    def test_animals_can_speak(self):
        """Animals that can speak are correctly identified"""
        print(BookInfo.objects.all())