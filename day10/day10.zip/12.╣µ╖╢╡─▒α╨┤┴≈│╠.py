# author luke
# 2022年02月24日


def main():
    print('这里是主流程代码')


if __name__ == '__main__':  #这个下面的代码不会被其他文件导入
    main()
