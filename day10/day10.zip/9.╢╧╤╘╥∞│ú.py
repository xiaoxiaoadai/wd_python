# author luke
# 2022年02月24日


try:
    assert 1==0
except AssertionError:
    print('断言异常')