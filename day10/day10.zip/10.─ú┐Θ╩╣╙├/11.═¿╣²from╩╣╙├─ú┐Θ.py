# author luke
# 2022年02月24日
from test_module import say_hello as module_say_hello
from test_module2 import say_hello
from test_module2 import *

module_say_hello()
say_hello()
print(title)
dog=Dog()