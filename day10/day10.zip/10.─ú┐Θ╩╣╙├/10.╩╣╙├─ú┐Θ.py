# author luke
# 2022年02月24日

import test_module as DogModule

print(DogModule.title)
DogModule.say_hello()
dog1=DogModule.Dog()
print(dog1)
print(DogModule.__name__)