# author luke
# 2022年02月24日
import random

print(random.__file__)

rand = random.randint(0, 10)

print(rand)