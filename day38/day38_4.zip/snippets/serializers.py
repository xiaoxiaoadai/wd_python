# 作者: 王道 龙哥
# 2022年03月26日11时53分11秒
from rest_framework import serializers
from snippets.models import Snippet, LANGUAGE_CHOICES, STYLE_CHOICES


# 在序列化类中没有的created字段，查询时得不到，新增也不需要提交这个字段
# 继承了HyperlinkedModelSerializer就会有url字段
class SnippetSerializer(serializers.HyperlinkedModelSerializer):
    # owner.username 的owner代表user对象，
    owner = serializers.ReadOnlyField(source='owner.username')
    # 自定义一个超链接字段，view_name在urls中配置过
    # highlight = serializers.HyperlinkedIdentityField(view_name='snippet-highlight',format='html')
    class Meta:
        model=Snippet
        fields=('id','title', 'code', 'linenos', 'language', 'style','owner')

from django.contrib.auth.models import User

class UserSerializer(serializers.ModelSerializer):
    snippets = serializers.PrimaryKeyRelatedField(many=True, queryset=Snippet.objects.all())

    class Meta:
        model = User
        fields = ['id', 'username', 'snippets']