# 作者: 王道 龙哥
# 2022年03月28日11时13分47秒
from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns

from snippets import views

# urlpatterns = [
#     path('snippets/', views.snippet_list),
#     path('snippets/<int:pk>/', views.snippet_detail),
# ]

urlpatterns = [
    path('', views.api_root),
    path('snippets/', views.SnippetList.as_view(),name='snippet-list'),
    path('snippets/<int:pk>/', views.SnippetDetail.as_view(),name='snippet-detail'),
    path('snippets/<int:pk>/highlight/',  views.SnippetHighlight.as_view(),name='snippet-highlight'),
    path('users/', views.UserList.as_view(),name='user-list'),
    path('users/<int:pk>/', views.UserDetail.as_view(),name='user-detail'),
]

# 为了让url支持json
urlpatterns = format_suffix_patterns(urlpatterns)
