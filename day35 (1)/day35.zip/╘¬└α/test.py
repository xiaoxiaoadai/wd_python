# 作者: 王道 龙哥
# 2022年03月25日11时16分45秒
class ObjectCreator(object):
    pass
