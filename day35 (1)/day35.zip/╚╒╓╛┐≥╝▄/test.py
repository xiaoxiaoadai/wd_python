# 作者: 王道 龙哥
# 2022年03月25日10时30分31秒
import logging
print(logging.DEBUG)