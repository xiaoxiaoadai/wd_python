# 作者: 王道 龙哥
# 2022年04月01日16时20分34秒
from rest_framework.throttling import UserRateThrottle


class BurstRateThrottle(UserRateThrottle):
    scope = 'burst'