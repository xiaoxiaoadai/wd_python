# 作者: 王道 龙哥
# 2022年03月30日11时14分02秒
from django.contrib import admin
from django.urls import path, include, re_path

#re_path里边第一个参数是正则表达式
from rest_framework.routers import DefaultRouter

from guides.views import *
router = DefaultRouter()  # 帮我们做了list，detail的方法跳转对应
# 官网这里写了basename搞错了，害死人
router.register(r'comments', CommentViewSet)
router.register(r'events', EventViewSet)
router.register(r'event1s', Event1ViewSet)
router.register(r'users', UserViewSet)
router.register(r'albums', AlbumViewSet)
router.register(r'tracks', TrackViewSet)

urlpatterns = [
    path('upload/<str:filename>/', FileUploadView.as_view()),
    path('simple_html_view/',simple_html_view),
    path('example_view/',example_view),
    path('example_view1/',ExampleView.as_view()),
]

urlpatterns+=router.urls