from django.test import TestCase

# Create your tests here.
import datetime

print(datetime.datetime(2000,1,2))