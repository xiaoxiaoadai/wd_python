from django.shortcuts import render

# Create your views here.
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import views
from rest_framework.decorators import api_view, renderer_classes, throttle_classes
from rest_framework.pagination import PageNumberPagination
from rest_framework.parsers import FileUploadParser
from rest_framework.renderers import StaticHTMLRenderer
from rest_framework.response import Response
from rest_framework.throttling import UserRateThrottle
from rest_framework.views import APIView

from .models import *
from .serializers import *
from .throttles import BurstRateThrottle


class FileUploadView(views.APIView):
    parser_classes = (FileUploadParser,)

    def put(self, request, filename, format=None):
        file_obj = request.data['file']  # 通过file拿到文件对象
        # ...
        # do some stuff with uploaded file
        # ...
        return Response(status=204)


@api_view(['GET'])
@renderer_classes([StaticHTMLRenderer])
def simple_html_view(request):
    data = '<html><body><h1>Hello, world</h1></body></html>'
    return Response(data)


from rest_framework.viewsets import ModelViewSet


class CommentViewSet(ModelViewSet):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer


class EventViewSet(ModelViewSet):
    queryset = Event.objects.all().order_by('id')
    serializer_class = EventSerializer


class Event1ViewSet(ModelViewSet):
    queryset = Event1.objects.all()
    serializer_class = Event1Serializer


class UserViewSet(ModelViewSet):
    queryset = User.objects.all()
    serializer_class = CreateUserSerializer


class AlbumViewSet(ModelViewSet):


    queryset = Album.objects.all()
    serializer_class = AlbumSerializer

#分页类
class StandardResultsSetPagination(PageNumberPagination):
    page_size = 2
    page_size_query_param = 'page_size'  #page_size_query_param名字不能变
    max_page_size = 1000


from rest_framework import filters
class TrackViewSet(ModelViewSet):
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = '__all__'
    search_fields = ['order', 'title', 'album__album_name']  # 外键加入两个下划线
    ordering_fields = '__all__'

    queryset = Track.objects.all()
    serializer_class = TrackSerializer
    pagination_class = StandardResultsSetPagination
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated

@api_view(['GET'])
@permission_classes([IsAuthenticated])
@throttle_classes([UserRateThrottle])
def example_view(request, format=None):
    content = {
        'status': 'request was permitted'
    }
    return Response(content)


class ExampleView(APIView):
    # throttle_classes = [BurstRateThrottle]
    throttle_scope = 'contacts'
    def get(self, request, format=None):
        content = {
            'status': 'request was permitted'
        }
        return Response(content)
