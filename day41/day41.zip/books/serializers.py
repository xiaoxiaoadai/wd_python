# 作者: 王道 龙哥
# 2022年03月26日11时02分48秒
from django.utils import timezone
from rest_framework import serializers
from rest_framework.validators import UniqueValidator, UniqueForYearValidator, UniqueForMonthValidator, \
    UniqueForDateValidator

from books.models import BookInfo



class BookInfoSerializer(serializers.ModelSerializer):
    """专门用于对图书进行进行序列化和反序列化的类: 序列化器类"""
    # btitle=serializers.CharField(max_length=20,validators=[UniqueValidator(queryset=BookInfo.objects.all())])
    btitle = serializers.CharField(max_length=20)
    # published = serializers.HiddenField(default=timezone.now)  #用户不需要在前端提交,前端也不会显示
    # owner = serializers.CharField(
    #     default=serializers.CurrentUserDefault()  #自动拿到当前登录的用户
    # )
    class Meta:
        # 当前序列化器在序列化数据的时候,使用哪个模型
        model = BookInfo
        # fields = ["id","btitle"] # 多个字段可以使用列表声明,如果是所有字段都要转换,则使用 '__all__'
        fields = ['id','btitle','bpub_date','bread','bcomment'] # 多个字段可以使用列表声明,如果是所有字段都要转换,则使用 '__all__'
        validators = [
            UniqueForDateValidator(
                queryset=BookInfo.objects.all(),
                field='btitle',  #书名和日期必须联合唯一
                date_field='bpub_date'
            )
        ]
